package com.kidozh.photi

import android.os.Bundle
import com.kidozh.photi.databinding.ActivityMainBinding
import com.kidozh.photi.utils.BaseAmbientActivity

class MainActivity : BaseAmbientActivity() {
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}