package com.kidozh.photi.utils

import android.os.Bundle
import android.os.PersistableBundle
import androidx.fragment.app.FragmentActivity
import androidx.wear.ambient.AmbientModeSupport

open class BaseAmbientActivity: FragmentActivity(), AmbientModeSupport.AmbientCallbackProvider {

    public lateinit var ambientController : AmbientModeSupport.AmbientController


    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState, persistentState)
        ambientController = AmbientModeSupport.attach(this)
    }

    override fun getAmbientCallback(): AmbientModeSupport.AmbientCallback {
        return BaseAmbientCallback()
    }

    public class BaseAmbientCallback : AmbientModeSupport.AmbientCallback(){

    }
}