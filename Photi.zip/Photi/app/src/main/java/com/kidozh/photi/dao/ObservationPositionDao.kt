package com.kidozh.photi.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.kidozh.photi.entity.ObservationPosition

@Dao
interface ObservationPositionDao {

    @Query("SELECT * FROM ObservationPosition")
    fun getAllObservationPositionList(): List<ObservationPosition>

    @Query("SELECT * FROM ObservationPosition")
    fun getAllObservationPositionLiveDataList(): LiveData<List<ObservationPosition>>

    @Insert
    fun insert(observationPosition: ObservationPosition)

    @Delete
    fun delete(observationPosition: ObservationPosition)
}